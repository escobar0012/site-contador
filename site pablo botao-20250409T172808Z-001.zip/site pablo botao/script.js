// script.js
document.getElementById('meuBotao').addEventListener('click', function() {
    alert('deixe de ser curioso rapaz!');
});
